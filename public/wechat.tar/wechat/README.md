# 微信小程序-知乎日报

* 模拟知乎日报的首页
* 跳转的文章页（但是识别不了HTML,所以内容无法显示）

## 预览

![](images/zhihu.gif)

## 使用

克隆本项目 -> 在微信开发工具中添加项目 -> 选择项目目录

## 资源

* [官方文档](https://mp.weixin.qq.com/debug/wxadoc/dev/?t=1474644083132)
* [开发工具下载](https://mp.weixin.qq.com/debug/wxadoc/dev/devtools/download.html?t=1474644089359)
