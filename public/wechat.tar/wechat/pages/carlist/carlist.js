Page({
  data: {
    inputVal: '',
    brands: [],
    isShowType: false,
    types: [],
  },
  onLoad() {
    var self = this;
    wx.request({
      url: "http://localhost:3000/brands",
      success(res) {
        self.setData({
          brands: res.data
        });
      }
    })
  },
  loadTypes(event) {
    var self = this;
    wx.request({
      url: "http://localhost:3000/types?id=" + event.currentTarget.dataset.id,
      success(res) {
        self.setData({
          types: res.data,
          isShowType: true
        });
      }
    })
  },
  hidenTypes() {
    this.setData({
      isShowType: false
    });
  },
  clearInput() {
    this.setData({
      inputVal: ''
    })
  },
  inputTyping(e) {
    this.setData({
      inputVal: e.detail.value
    })
  }
})