Page({
  data: {
    inputVal: '',
    brands: [],
    isShowType: false,
    types: [],
  },
  onLoad(options) {
    var self = this;
    console.log(options)
    /* 
    wx.request({
      url: "http://localhost:3000/type",
      success(res) {
        self.setData({
          brands: res.data
        });
      }
    }) */
  }
})